# Garbage classification > 2022-03-10 4:06pm
https://universe.roboflow.com/jakob-kruijer/garbage-classification-fw9gx

Provided by a Roboflow user
License: CC BY 4.0

